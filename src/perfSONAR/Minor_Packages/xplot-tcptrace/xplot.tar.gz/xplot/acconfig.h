/* Define if your struct tm has gmtoff */
#undef HAVE_TM_GMTOFF

/* Define if your <time.h> has extern time_t altzone */
#undef HAS_ALTZONE
